#include <Arduino.h>
#include <M5Core2.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <WiFi.h>
#include "functs.h"

// Variables for test data
int aleatorio = 0;
int estado = 0; // escolheu rotina
int entrada = 0;
int cont_entrada = 0;
unsigned long startTime = 0;
bool buttonPressed = false;
unsigned long buttonPressTime = 0; // Tempo de início da contagem
unsigned long elapsedTime = 0;     // Tempo decorrido
int responseReceived = 0;
int rotina;

esp_err_t result;

void reset(void)
{
  estado = 0;
  entrada = 0;
  cont_entrada = 0;
  startTime = 0;
  buttonPressed = false;
  buttonPressTime = 0; // Tempo de início da contagem
  elapsedTime = 0;     // Tempo decorrido
  responseReceived = false;
}

void setup()
{
  M5.begin();
  M5.Lcd.fillScreen(BLACK);
  M5.Lcd.setCursor(10, 10);
  M5.Lcd.setTextColor(WHITE);
  M5.Lcd.setTextSize(1);
  M5.Lcd.println("MAC Address");
  M5.Lcd.println(WiFi.macAddress()); // Printa na Serial a MAC dele
  M5.Lcd.printf("ID: ");
  M5.Lcd.print(BOARD_ID);

  if (init_esp_now() == false)
    return;

  if (addPeer(Slave_Address_1, CHANNEL) == false)
    return; // Adiciona os endereços e crasha o programa se não conseguir adicionar
  if (addPeer(Slave_Address_2, CHANNEL) == false)
    return;
  if (addPeer(Slave_Address_3, CHANNEL) == false)
    return;
  if (addPeer(Slave_Address_4, CHANNEL) == false)
    return;
}

void rotina1(void)
{
  int percorre = 0;
  while (cont_entrada < entrada)
  {
    for (int percorre = 1; percorre < 5; percorre++)
    {
      if (percorre == 1)
      {
        myData.id = 1;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_1, (uint8_t *)&myData, sizeof(myData)); // Realiza o envio da mensagem para endereço selecionado
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 1");
        else
          Serial.println("Error sending the data to slave 1");
        Serial.println("Aguardando resposta do slave 1");
        while (recebido != 11)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 2)
      {
        myData.id = 2;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_2, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 2");
        else
          Serial.println("Error sending the data to slave 2");
        Serial.println("Aguardando resposta do slave 2");
        while (recebido != 22)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 3)
      {
        myData.id = 3;
        myData.rotina = 0;
        vTaskDelay(200);
        result = esp_now_send(Slave_Address_3, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 3");
        else
          Serial.println("Error sending the data to slave 3");
        Serial.println("Aguardando resposta do slave 3");
        while (recebido != 33)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 4)
      {
        myData.id = 4;
        myData.rotina = 0;
        vTaskDelay(200);
        result = esp_now_send(Slave_Address_4, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 4");
        else
          Serial.println("Error sending the data to slave 4");
        Serial.println("Aguardando resposta do slave 4");
        while (recebido != 44)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      cont_entrada++;
    }
  }
}

void rotina2(void)
{
  int percorre = 0;
  int a = 0;
  int aleatorio = 0;
  while (cont_entrada < entrada)
  {
    for (int percorre = 1; percorre < 5; percorre++)
    {
      aleatorio = random(1, 5);
      if (cont_entrada != 0)
      {
        while (a == aleatorio)
          aleatorio = random(1, 5);
      }
      a = aleatorio;
      if (a == 1)
      {
        myData.id = 1;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_1, (uint8_t *)&myData, sizeof(myData)); // Realiza o envio da mensagem para endereço selecionado
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 1");
        else
          Serial.println("Error sending the data to slave 1");
        Serial.println("Aguardando resposta do slave 1");
        while (recebido != 11)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (a == 2)
      {
        myData.id = 2;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_2, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 2");
        else
          Serial.println("Error sending the data to slave 2");
        Serial.println("Aguardando resposta do slave 2");
        while (recebido != 22)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (a == 3)
      {
        myData.id = 3;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_3, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 3");
        else
          Serial.println("Error sending the data to slave 3");
        Serial.println("Aguardando resposta do slave 3");
        while (recebido != 33)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(100);
      }
      else if (a == 4)
      {
        myData.id = 4;
        myData.rotina = 0;
        result = esp_now_send(Slave_Address_4, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 4");
        else
          Serial.println("Error sending the data to slave 4");
        Serial.println("Aguardando resposta do slave 4");
        while (recebido != 44)
        {
          vTaskDelay(100);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      cont_entrada++;
    }
  }
}

void rotina3(void)
{
  int percorre = 0;
  if (rotina == 1)
  {
    myData.rotina = 1;
  }
  else if (rotina == 2)
  {
    myData.rotina = 2;
  }
  while (cont_entrada < entrada)
  {
    for (int percorre = 1; percorre < 5; percorre++)
    {
      if (percorre == 1)
      {
        myData.id = 1;
        result = esp_now_send(Slave_Address_1, (uint8_t *)&myData, sizeof(myData)); // Realiza o envio da mensagem para endereço selecionado
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 1");
        else
          Serial.println("Error sending the data to slave 1");
        Serial.println("Aguardando resposta do slave 1");
        while (recebido != 11)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 2)
      {
        myData.id = 2;
        result = esp_now_send(Slave_Address_2, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 2");
        else
          Serial.println("Error sending the data to slave 2");
        Serial.println("Aguardando resposta do slave 2");
        while (recebido != 22)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 3)
      {
        myData.id = 3;
        result = esp_now_send(Slave_Address_3, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 3");
        else
          Serial.println("Error sending the data to slave 3");
        Serial.println("Aguardando resposta do slave 3");
        while (recebido != 33)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (percorre == 4)
      {
        myData.id = 4;
        result = esp_now_send(Slave_Address_4, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 4");
        else
          Serial.println("Error sending the data to slave 4");
        Serial.println("Aguardando resposta do slave 4");
        while (recebido != 44)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      cont_entrada++;
      Serial.println(cont_entrada);
    }
  }
}

void rotina4(void)
{
  int a = 0;
  int aleatorio = 0;
  if (rotina == 1)
  {
    myData.rotina = 1;
  }
  else if (rotina == 2)
  {
    myData.rotina = 2;
  }
  while (cont_entrada < entrada)
  {
    for (int percorre = 1; percorre < 5; percorre++)
    {
      aleatorio = random(1, 5);
      if (cont_entrada != 0)
      {
        while (a == aleatorio)
          aleatorio = random(1, 5);
      }
      a = aleatorio;
      if (a == 1)
      {
        myData.id = 1;
        result = esp_now_send(Slave_Address_1, (uint8_t *)&myData, sizeof(myData)); // Realiza o envio da mensagem para endereço selecionado
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 1");
        else
          Serial.println("Error sending the data to slave 1");
        Serial.println("Aguardando resposta do slave 1");
        while (recebido != 11)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (a == 2)
      {
        myData.id = 2;
        result = esp_now_send(Slave_Address_2, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 2");
        else
          Serial.println("Error sending the data to slave 2");
        Serial.println("Aguardando resposta do slave 2");
        while (recebido != 22)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (a == 3)
      {
        myData.id = 3;
        result = esp_now_send(Slave_Address_3, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 3");
        else
          Serial.println("Error sending the data to slave 3");
        Serial.println("Aguardando resposta do slave 3");
        while (recebido != 33)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      else if (a == 4)
      {
        myData.id = 4;
        result = esp_now_send(Slave_Address_4, (uint8_t *)&myData, sizeof(myData));
        if (result == ESP_OK)
          Serial.println("Sent with success to slave 4");
        else
          Serial.println("Error sending the data to slave 4");
        Serial.println("Aguardando resposta do slave 4");
        while (recebido != 44)
        {
          vTaskDelay(2);
        }
        recebido = 0;
        vTaskDelay(200);
      }
      cont_entrada++;
    }
  }
}

void start_count()
{
  buttonPressTime = millis();
}
void end_count()
{
  elapsedTime = millis() - buttonPressTime;

  // Exibe o tempo decorrido em segundos
  Serial.println("Tempo decorrido: ");
  Serial.print(elapsedTime / 1000);
  Serial.print(".");
  Serial.print((elapsedTime % 1000) / 100); // Exibe a primeira casa decimal
  Serial.print((elapsedTime % 100) / 10);   // Exibe a segunda casa decimal
  Serial.print((elapsedTime % 10));         // Exibe a terceira casa decimal
  Serial.println(" segundos");
}

void selecionaRotina(void)
{
  Serial.println("Selecione a rotina que deseja executar:\n1 - Rotina 1;\n2 - Rotina 2;\n3 - Rotina 3;\n4 - Rotina 4;\n5 - Rotina 5;\n6 - Rotina 6;\n");
  while (!Serial.available())
  {
    // Aguarda até que os dados estejam disponíveis na porta serial
  }
  // Lê a opção escolhida pelo usuário
  String option = Serial.readString();
  // Remove quaisquer espaços em branco no início e no final da opção
  option.trim();
  Serial.println(option);
  while (estado == 0)
  {
    if (option.equals("1"))
    {
      estado = 1;
      rotina = 0;
      start_count();
      rotina1();
      end_count();
    }
    if (option.equals("2"))
    {
      estado = 1;
      rotina = 0;
      start_count();
      rotina2();
      end_count();
    }
    if (option.equals("3"))
    {
      estado = 1;
      start_count();
      rotina = 1;
      rotina3();
      end_count();
    }
    if (option.equals("4"))
    {
      estado = 1;
      rotina = 1;
      start_count();
      rotina4();
      end_count();
    }
    if (option.equals("5"))
    {
      estado = 1;
      rotina = 2;
      start_count();
      rotina4();
      end_count();
    }
    if (option.equals("6"))
    {
      estado = 1;
      rotina=2;
      start_count();
      rotina4();
      end_count();
    }
  }
}
void repeticoes(void)
{
  Serial.println("\nEscreva o numero de repetições que deseja executar:\n");
  while (!Serial.available())
  {
    // Aguarda até que os dados estejam disponíveis na porta serial
  }
  // Lê a opção escolhida pelo usuário
  String num_rep = Serial.readString();
  // Remove quaisquer espaços em branco no início e no final da opção
  num_rep.trim();
  int intnum_rep = num_rep.toInt();
  entrada = intnum_rep;
  entrada = entrada * 4;
}

// Para realizar os envios, seguir está estrutura que desenhei
void loop()
{
  reset();
  vTaskDelay(200);
  repeticoes();
  selecionaRotina();
}
